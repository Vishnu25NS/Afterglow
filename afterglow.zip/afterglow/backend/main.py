"""Afterglow backend: library, audio streaming, analysis queue, playlists.

Run from this folder:  uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import sqlite3
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from analysis import analyze_track, read_tags, save_cover

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("AFTERGLOW_DATA", BASE / "data"))
TRACKS_DIR = DATA / "tracks"
COVERS_DIR = DATA / "covers"
ANALYSIS_DIR = DATA / "analysis"
DB_PATH = DATA / "afterglow.db"
STATIC_DIR = Path(os.environ.get("AFTERGLOW_STATIC", BASE.parent / "frontend"))

ALLOWED_EXT = {".mp3", ".wav", ".flac", ".ogg", ".oga", ".m4a", ".aac", ".opus", ".webm"}
MAX_UPLOAD_MB = int(os.environ.get("AFTERGLOW_MAX_UPLOAD_MB", "200"))
WORKERS = int(os.environ.get("AFTERGLOW_ANALYSIS_WORKERS", "2"))

for _p in (TRACKS_DIR, COVERS_DIR, ANALYSIS_DIR):
    _p.mkdir(parents=True, exist_ok=True)

mimetypes.add_type("audio/mp4", ".m4a")
mimetypes.add_type("audio/ogg", ".opus")
mimetypes.add_type("audio/flac", ".flac")
mimetypes.add_type("audio/aac", ".aac")

POOL = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="analysis")


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    return con


def fetch(sql: str, args: tuple = ()) -> list[sqlite3.Row]:
    con = _connect()
    try:
        return con.execute(sql, args).fetchall()
    finally:
        con.close()


def execute(sql: str, args: tuple = ()) -> None:
    con = _connect()
    try:
        con.execute(sql, args)
        con.commit()
    finally:
        con.close()


def init_db() -> None:
    con = _connect()
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS tracks(
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                artist TEXT,
                album TEXT,
                filename TEXT NOT NULL,
                ext TEXT NOT NULL,
                duration REAL,
                status TEXT NOT NULL DEFAULT 'queued',
                error TEXT,
                has_cover INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS playlists(
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                track_ids TEXT NOT NULL DEFAULT '[]',
                created_at REAL NOT NULL
            );
            """
        )
        con.commit()
    finally:
        con.close()


def track_out(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "artist": row["artist"],
        "album": row["album"],
        "duration": row["duration"],
        "status": row["status"],
        "error": row["error"],
        "has_cover": bool(row["has_cover"]),
        "created_at": row["created_at"],
    }


def playlist_out(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "name": row["name"], "track_ids": json.loads(row["track_ids"])}


def get_track_row(track_id: str) -> sqlite3.Row:
    rows = fetch("SELECT * FROM tracks WHERE id=?", (track_id,))
    if not rows:
        raise HTTPException(404, "Track not found")
    return rows[0]


# --------------------------------------------------------------------------
# Analysis queue
# --------------------------------------------------------------------------
def analyze_job(track_id: str) -> None:
    rows = fetch("SELECT * FROM tracks WHERE id=?", (track_id,))
    if not rows:
        return
    row = rows[0]
    execute("UPDATE tracks SET status='analyzing', error=NULL WHERE id=?", (track_id,))
    try:
        cover = COVERS_DIR / f"{track_id}.jpg"
        result = analyze_track(TRACKS_DIR / row["filename"], cover if cover.exists() else None)
        if not fetch("SELECT 1 FROM tracks WHERE id=?", (track_id,)):
            return  # deleted while analysing
        (ANALYSIS_DIR / f"{track_id}.json").write_text(json.dumps(result, separators=(",", ":")))
        execute(
            "UPDATE tracks SET status='ready', duration=?, error=NULL WHERE id=?",
            (result["duration"], track_id),
        )
    except Exception as exc:  # keep the track playable even if analysis fails
        traceback.print_exc()
        execute("UPDATE tracks SET status='error', error=? WHERE id=?", (str(exc)[:300], track_id))


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    for row in fetch("SELECT id FROM tracks WHERE status IN ('queued','analyzing')"):
        POOL.submit(analyze_job, row["id"])
    yield
    POOL.shutdown(wait=False, cancel_futures=True)


app = FastAPI(title="Afterglow", lifespan=lifespan)


# --------------------------------------------------------------------------
# Tracks
# --------------------------------------------------------------------------
@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/tracks")
def list_tracks():
    return [track_out(r) for r in fetch("SELECT * FROM tracks ORDER BY created_at ASC")]


@app.get("/api/tracks/{track_id}")
def get_track(track_id: str):
    return track_out(get_track_row(track_id))


async def _save_upload(up: UploadFile, dest: Path) -> None:
    limit = MAX_UPLOAD_MB * 1024 * 1024
    size = 0
    try:
        with dest.open("wb") as fh:
            while chunk := await up.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise HTTPException(413, f"File is larger than {MAX_UPLOAD_MB} MB")
                fh.write(chunk)
    except Exception:
        dest.unlink(missing_ok=True)
        raise


@app.post("/api/tracks", status_code=201)
async def upload_tracks(files: List[UploadFile] = File(...)):
    created, skipped = [], []
    base_ts = time.time()
    for n, up in enumerate(files):
        name = up.filename or "untitled"
        ext = Path(name).suffix.lower()
        if ext not in ALLOWED_EXT:
            skipped.append(name)
            continue
        track_id = uuid.uuid4().hex[:12]
        filename = f"{track_id}{ext}"
        dest = TRACKS_DIR / filename
        await _save_upload(up, dest)

        tags = await run_in_threadpool(read_tags, dest)
        has_cover = False
        if tags["cover"]:
            has_cover = await run_in_threadpool(save_cover, tags["cover"], COVERS_DIR / f"{track_id}.jpg")
        title = tags["title"] or Path(name).stem.replace("_", " ").strip() or "Untitled"
        execute(
            "INSERT INTO tracks(id,title,artist,album,filename,ext,duration,status,has_cover,created_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (track_id, title, tags["artist"], tags["album"], filename, ext, tags["duration"],
             "queued", int(has_cover), base_ts + n * 0.001),
        )
        POOL.submit(analyze_job, track_id)
        created.append(track_out(get_track_row(track_id)))
    if not created:
        raise HTTPException(415, "No supported audio files. Use mp3, wav, flac, ogg, m4a, aac or opus.")
    return {"tracks": created, "skipped": skipped}


@app.delete("/api/tracks/{track_id}", status_code=204)
def delete_track(track_id: str):
    row = get_track_row(track_id)
    (TRACKS_DIR / row["filename"]).unlink(missing_ok=True)
    (COVERS_DIR / f"{track_id}.jpg").unlink(missing_ok=True)
    (ANALYSIS_DIR / f"{track_id}.json").unlink(missing_ok=True)
    execute("DELETE FROM tracks WHERE id=?", (track_id,))
    for pl in fetch("SELECT * FROM playlists"):
        ids = json.loads(pl["track_ids"])
        if track_id in ids:
            execute("UPDATE playlists SET track_ids=? WHERE id=?",
                    (json.dumps([i for i in ids if i != track_id]), pl["id"]))
    return Response(status_code=204)


@app.post("/api/tracks/{track_id}/reanalyze", status_code=202)
def reanalyze(track_id: str):
    get_track_row(track_id)
    execute("UPDATE tracks SET status='queued', error=NULL WHERE id=?", (track_id,))
    POOL.submit(analyze_job, track_id)
    return {"status": "queued"}


@app.get("/api/tracks/{track_id}/analysis")
def get_analysis(track_id: str):
    row = get_track_row(track_id)
    path = ANALYSIS_DIR / f"{track_id}.json"
    if row["status"] != "ready" or not path.exists():
        return Response(
            content=json.dumps({"status": row["status"], "error": row["error"]}),
            status_code=202,
            media_type="application/json",
        )
    return FileResponse(path, media_type="application/json", headers={"Cache-Control": "private, max-age=3600"})


@app.get("/api/tracks/{track_id}/cover")
def get_cover(track_id: str):
    path = COVERS_DIR / f"{track_id}.jpg"
    if not path.exists():
        raise HTTPException(404, "No cover")
    return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=86400"})


@app.get("/api/tracks/{track_id}/audio")
def get_audio(track_id: str, request: Request):
    row = get_track_row(track_id)
    path = TRACKS_DIR / row["filename"]
    if not path.exists():
        raise HTTPException(404, "Audio file missing")
    media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return _range_response(path, request, media_type)


def _range_response(path: Path, request: Request, media_type: str):
    """Serve a file with HTTP Range support so seeking works in every browser."""
    size = path.stat().st_size
    headers = {"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=3600"}
    header = request.headers.get("range")
    if not header:
        return FileResponse(path, media_type=media_type, headers=headers)
    m = re.match(r"bytes=(\d*)-(\d*)$", header.strip())
    if not m or (m.group(1) == "" and m.group(2) == ""):
        raise HTTPException(416, "Bad range", headers={"Content-Range": f"bytes */{size}"})
    if m.group(1) == "":
        start, end = max(size - int(m.group(2)), 0), size - 1
    else:
        start = int(m.group(1))
        end = int(m.group(2)) if m.group(2) else size - 1
    end = min(end, size - 1)
    if start > end or start >= size:
        raise HTTPException(416, "Range not satisfiable", headers={"Content-Range": f"bytes */{size}"})

    def body():
        remaining = end - start + 1
        with path.open("rb") as fh:
            fh.seek(start)
            while remaining > 0:
                chunk = fh.read(min(64 * 1024, remaining))
                if not chunk:
                    break
                remaining -= len(chunk)
                yield chunk

    headers.update({"Content-Range": f"bytes {start}-{end}/{size}", "Content-Length": str(end - start + 1)})
    return StreamingResponse(body(), status_code=206, media_type=media_type, headers=headers)


# --------------------------------------------------------------------------
# Playlists
# --------------------------------------------------------------------------
class PlaylistIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)


class PlaylistPatch(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=60)
    track_ids: Optional[List[str]] = None


def _playlist_row(pid: str) -> sqlite3.Row:
    rows = fetch("SELECT * FROM playlists WHERE id=?", (pid,))
    if not rows:
        raise HTTPException(404, "Playlist not found")
    return rows[0]


@app.get("/api/playlists")
def list_playlists():
    return [playlist_out(r) for r in fetch("SELECT * FROM playlists ORDER BY created_at ASC")]


@app.post("/api/playlists", status_code=201)
def create_playlist(body: PlaylistIn):
    pid = uuid.uuid4().hex[:10]
    execute("INSERT INTO playlists(id,name,track_ids,created_at) VALUES(?,?,?,?)",
            (pid, body.name.strip(), "[]", time.time()))
    return playlist_out(_playlist_row(pid))


@app.put("/api/playlists/{pid}")
def update_playlist(pid: str, body: PlaylistPatch):
    row = _playlist_row(pid)
    name = body.name.strip() if body.name else row["name"]
    ids = json.loads(row["track_ids"])
    if body.track_ids is not None:
        known = {r["id"] for r in fetch("SELECT id FROM tracks")}
        ids = [i for i in body.track_ids if i in known]
    execute("UPDATE playlists SET name=?, track_ids=? WHERE id=?", (name, json.dumps(ids), pid))
    return playlist_out(_playlist_row(pid))


@app.delete("/api/playlists/{pid}", status_code=204)
def delete_playlist(pid: str):
    _playlist_row(pid)
    execute("DELETE FROM playlists WHERE id=?", (pid,))
    return Response(status_code=204)


# --------------------------------------------------------------------------
# Frontend (mounted last so /api wins)
# --------------------------------------------------------------------------
if STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

"""Offline track analysis for Afterglow.

One pass per uploaded track produces a "beat map" the browser can render from:
beat times with accents, bass/mid/high/energy curves on a 100 ms grid,
section boundaries, and a colour palette (album art first, audio fallback).
"""
from __future__ import annotations

import base64
import colorsys
import io
from pathlib import Path
from typing import Optional

import librosa
import numpy as np
from mutagen import File as MutagenFile
from PIL import Image

SR = 22050
HOP = 512
GRID = 0.1  # seconds per energy sample
ANALYSIS_VERSION = 1


# --------------------------------------------------------------------------
# Tags and cover art
# --------------------------------------------------------------------------
def _extract_cover(mf) -> Optional[bytes]:
    try:
        pics = getattr(mf, "pictures", None)  # FLAC
        if pics:
            return pics[0].data
        tags = mf.tags
        if tags is None:
            return None
        for key in list(tags.keys()):  # MP3 / ID3
            if str(key).startswith("APIC"):
                return tags[key].data
        if "covr" in tags:  # MP4 / M4A
            vals = tags["covr"]
            if vals:
                return bytes(vals[0])
        mbp = tags.get("metadata_block_picture") if hasattr(tags, "get") else None
        if mbp:  # Ogg Vorbis / Opus
            from mutagen.flac import Picture

            return Picture(base64.b64decode(mbp[0])).data
    except Exception:
        return None
    return None


def read_tags(path: Path) -> dict:
    out = {"title": None, "artist": None, "album": None, "duration": None, "cover": None}
    try:
        mf = MutagenFile(str(path))
        if mf is not None:
            if mf.info is not None and getattr(mf.info, "length", None):
                out["duration"] = float(mf.info.length)
            out["cover"] = _extract_cover(mf)
        easy = MutagenFile(str(path), easy=True)
        if easy is not None and easy.tags:
            for key in ("title", "artist", "album"):
                vals = easy.tags.get(key)
                if vals:
                    out[key] = str(vals[0]).strip() or None
    except Exception:
        pass
    return out


def save_cover(data: bytes, dest: Path) -> bool:
    try:
        im = Image.open(io.BytesIO(data)).convert("RGB")
        im.thumbnail((600, 600))
        im.save(dest, "JPEG", quality=86)
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
# Palette
# --------------------------------------------------------------------------
def _hex(h: float, s: float, v: float) -> str:
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, min(1, max(0, s)), min(1, max(0, v)))
    return "#%02x%02x%02x" % (round(r * 255), round(g * 255), round(b * 255))


def _hue_dist(a: float, b: float) -> float:
    d = abs(a - b) % 1.0
    return min(d, 1 - d)


def fallback_palette(key: int, intensity: float) -> list[str]:
    h = (key % 12) / 12.0
    s = 0.6 + 0.3 * float(intensity)
    return [
        _hex(h, s, 0.16),
        _hex(h + 0.05, s, 0.50),
        _hex(h + 0.50, s * 0.9, 0.70),
        _hex(h - 0.06, s * 0.8, 0.90),
        _hex(h + 0.02, 0.25, 1.00),
    ]


def palette_from_image(path: Path, key: int = 0, intensity: float = 0.5, n: int = 5) -> list[str]:
    try:
        im = Image.open(path).convert("RGB")
        im.thumbnail((96, 96))
        q = im.quantize(colors=12, method=Image.Quantize.MEDIANCUT)
        pal = q.getpalette() or []
        colors = q.getcolors() or []
        total = sum(c for c, _ in colors) or 1
        cands = []
        for count, idx in colors:
            r, g, b = pal[idx * 3: idx * 3 + 3]
            h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            score = (count / total) ** 0.5 * 0.5 + s * 0.35 + v * 0.15
            cands.append((score, h, s, v))
        cands.sort(reverse=True)
        picked: list[tuple[float, float, float]] = []
        for _, h, s, v in cands:
            if all(_hue_dist(h, ph) > 0.06 or abs(v - pv) > 0.3 for ph, _, pv in picked):
                picked.append((h, s, v))
            if len(picked) >= n:
                break
        if not picked:
            return fallback_palette(key, intensity)
        k = 0
        while len(picked) < n:  # pad with analogues of the dominant colour
            k += 1
            h0, s0, v0 = picked[0]
            picked.append(((h0 + 0.07 * k) % 1.0, s0, min(1.0, v0 * (0.6 + 0.15 * k))))
        boosted = [(h, min(1.0, s * 1.2 + 0.08), min(0.97, max(0.25, v))) for h, s, v in picked]
        boosted.sort(key=lambda c: c[2])  # dark -> light gives depth in the shader
        h, s, v = boosted[0]
        boosted[0] = (h, s, min(v, 0.28))  # guarantee a dark anchor
        return [_hex(*c) for c in boosted]
    except Exception:
        return fallback_palette(key, intensity)


# --------------------------------------------------------------------------
# Main analysis
# --------------------------------------------------------------------------
def _norm_curve(v: np.ndarray, grid: np.ndarray, frame_t: np.ndarray) -> np.ndarray:
    v = np.interp(grid, frame_t, np.log1p(v))
    lo, hi = np.percentile(v, 5), np.percentile(v, 98)
    return np.clip((v - lo) / (hi - lo + 1e-9), 0, 1)


def analyze_track(path: Path, cover_path: Optional[Path] = None) -> dict:
    y, sr = librosa.load(str(path), sr=SR, mono=True)
    if y.size < sr:
        raise ValueError("Audio is shorter than one second")
    duration = float(y.size / sr)

    # Beats ----------------------------------------------------------------
    onset_env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=HOP)
    tempo, beat_frames = librosa.beat.beat_track(onset_envelope=onset_env, sr=sr, hop_length=HOP)
    tempo = float(np.atleast_1d(tempo)[0])
    beat_frames = np.asarray(beat_frames, dtype=int)
    beat_times = librosa.frames_to_time(beat_frames, sr=sr, hop_length=HOP)

    if len(beat_times) < 4 or tempo <= 0:  # no usable beat: fall back to a steady grid
        tempo = tempo if tempo > 0 else 120.0
        beat_times = np.arange(0, duration, 60.0 / tempo)
        accents = np.full(len(beat_times), 0.5)
        confident = False
    else:
        strengths = onset_env[np.clip(beat_frames, 0, len(onset_env) - 1)]
        norm = np.clip(strengths / (np.percentile(strengths, 95) + 1e-9), 0, 1)
        accents = 0.45 + 0.4 * norm
        if len(beat_times) >= 8:  # pick the bar phase (1 of 4) with the strongest beats
            phase = int(np.argmax([strengths[p::4].mean() for p in range(4)]))
            accents[phase::4] = 1.0
        confident = True

    # Band energy curves -----------------------------------------------------
    stft = np.abs(librosa.stft(y, n_fft=2048, hop_length=HOP))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
    frame_t = librosa.frames_to_time(np.arange(stft.shape[1]), sr=sr, hop_length=HOP)
    grid = np.arange(0, duration, GRID)

    def band(lo: float, hi: float) -> np.ndarray:
        m = (freqs >= lo) & (freqs < hi)
        return stft[m].mean(axis=0)

    bass = _norm_curve(band(30, 160), grid, frame_t)
    mid = _norm_curve(band(160, 2000), grid, frame_t)
    high = _norm_curve(band(2000, 9000), grid, frame_t)
    energy = 0.5 * bass + 0.3 * mid + 0.2 * high
    energy = np.convolve(energy, np.ones(5) / 5, mode="same")

    # Sections -------------------------------------------------------------------
    try:
        seg_hop = HOP * 4
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13, hop_length=seg_hop)
        k = int(np.clip(round(duration / 25), 2, 12))
        bounds = librosa.segment.agglomerative(mfcc, k)
        sections = sorted({round(float(t), 2) for t in librosa.frames_to_time(bounds, sr=sr, hop_length=seg_hop)})
        if not sections or sections[0] > 0:
            sections.insert(0, 0.0)
    except Exception:
        sections = [0.0]

    # Key, mood, palette -------------------------------------------------------------
    chroma = librosa.feature.chroma_stft(S=stft ** 2, sr=sr)
    key = int(np.argmax(chroma.mean(axis=1)))
    intensity = float(np.clip(energy.mean(), 0, 1))
    if tempo >= 120 and intensity > 0.5:
        mood = "energetic"
    elif tempo < 90 and intensity < 0.45:
        mood = "calm"
    elif intensity > 0.5:
        mood = "driving"
    else:
        mood = "mellow"

    if cover_path and cover_path.exists():
        palette = palette_from_image(cover_path, key, intensity)
    else:
        palette = fallback_palette(key, intensity)

    def r3(a: np.ndarray) -> list:
        return [round(float(x), 3) for x in a]

    return {
        "version": ANALYSIS_VERSION,
        "duration": round(duration, 3),
        "tempo": round(tempo, 2),
        "beat_confidence": confident,
        "beats": r3(beat_times),
        "accents": r3(accents),
        "sections": sections,
        "hop": GRID,
        "bass": r3(bass),
        "mid": r3(mid),
        "high": r3(high),
        "energy": r3(energy),
        "palette": palette,
        "key": key,
        "mood": mood,
        "intensity": round(intensity, 3),
    }

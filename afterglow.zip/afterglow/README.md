# Afterglow

A music app with a beat-reactive fullscreen visualizer. Upload songs, play them,
and the screen moves with the music, including smooth crossfades into the next song.

## Run it

Requires Python 3.10+ and ffmpeg (needed for m4a/aac/opus decoding).

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000. Or with Docker:
`docker build -t afterglow . && docker run -p 8000:8000 -v afterglow-data:/data afterglow`

## How it works

1. **Upload** -> the server stores the file, reads tags and cover art, and queues analysis.
2. **Analysis (librosa, once per track)** -> beat times with accents, bass/mid/high/energy curves
   (100 ms grid), section boundaries, mood, and a colour palette from the album art.
   Cached as JSON. Playback never waits for it: until it is ready, visuals use live FFT.
3. **Playback** -> two audio "decks" with equal-power crossfade (0 to 12 s). The next song is
   prefetched into the idle deck, together with its beat map, before the crossfade starts.
4. **Rendering** -> a WebGL2 shader driven by the audio clock: pulses land on beats, a swell
   builds just before each one, palettes and intensity blend between songs, and colours shift
   at section changes. Live FFT adds fine texture on top of the beat map.
5. Frame rate drops? Resolution scales down automatically.

## Controls

Space play/pause, Left/Right seek 5 s, Up/Down volume, N next, P previous, F fullscreen,
H hide interface, V change visual style, M mute.
`[` and `]` nudge visual sync by 10 ms if beats look early or late on your speakers/Bluetooth.

## API

| Method | Path | Purpose |
|---|---|---|
| GET/POST | /api/tracks | list / upload (multipart `files`) |
| DELETE | /api/tracks/{id} | delete song and cached data |
| GET | /api/tracks/{id}/audio | stream with Range support |
| GET | /api/tracks/{id}/analysis | beat map (202 while pending) |
| GET | /api/tracks/{id}/cover | cover art |
| POST | /api/tracks/{id}/reanalyze | rerun analysis |
| GET/POST/PUT/DELETE | /api/playlists[/{id}] | playlists |

## Config (env vars)

`AFTERGLOW_DATA` data folder (default `backend/data`), `AFTERGLOW_MAX_UPLOAD_MB` (200),
`AFTERGLOW_ANALYSIS_WORKERS` (2).

## Known limits / next steps

- Single user, no login. Add auth before exposing it to the internet.
- SQLite + local disk. Move to Postgres + S3 and a job queue (Celery/RQ) to scale.
- Beat tracking is strongest on steady, beat-driven music; free-time or ambient tracks
  fall back to energy-driven visuals.
- Respects `prefers-reduced-motion` (visual intensity is reduced).
